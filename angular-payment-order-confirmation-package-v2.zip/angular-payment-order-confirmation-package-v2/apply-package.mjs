import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packageDirectory = path.dirname(fileURLToPath(import.meta.url));

function findRepositoryRoot(requestedRoot) {
  const candidates = [];

  if (requestedRoot) {
    candidates.push(path.resolve(requestedRoot));
  }

  candidates.push(process.cwd());
  candidates.push(path.resolve(packageDirectory, '..'));

  for (const candidate of candidates) {
    const frontendPackage = path.join(
      candidate,
      'food-ordering-ui',
      'package.json'
    );

    if (fs.existsSync(frontendPackage)) {
      return candidate;
    }
  }

  throw new Error(
    'Unable to locate the OnlineFoodOrdering repository. ' +
      'Run this script from the repository root or pass the repository path.'
  );
}

function normalize(content) {
  return content.replace(/\r\n/g, '\n');
}

function detectLineEnding(content) {
  return content.includes('\r\n') ? '\r\n' : '\n';
}

function restoreLineEnding(content, lineEnding) {
  return normalize(content).replace(/\n/g, lineEnding);
}

function ensureDirectory(directory) {
  fs.mkdirSync(directory, { recursive: true });
}

function backupFile(filePath, repositoryRoot, backupRoot) {
  if (!fs.existsSync(filePath)) {
    return;
  }

  const relativePath = path.relative(repositoryRoot, filePath);
  const backupPath = path.join(backupRoot, relativePath);
  ensureDirectory(path.dirname(backupPath));
  fs.copyFileSync(filePath, backupPath);
}

function writePackageFile(sourcePath, targetPath) {
  const sourceContent = fs.readFileSync(sourcePath, 'utf8');
  const currentContent = fs.existsSync(targetPath)
    ? fs.readFileSync(targetPath, 'utf8')
    : '';
  const lineEnding = currentContent
    ? detectLineEnding(currentContent)
    : os.EOL;

  ensureDirectory(path.dirname(targetPath));
  fs.writeFileSync(
    targetPath,
    restoreLineEnding(sourceContent, lineEnding),
    'utf8'
  );
}

function replaceOrThrow(content, pattern, replacement, description) {
  if (!pattern.test(content)) {
    throw new Error(
      `Could not apply "${description}". ` +
        'The required code marker was not found.'
    );
  }

  console.log(`Applied: ${description}`);
  return content.replace(pattern, replacement);
}

function requireText(content, expectedText, description) {
  if (!content.includes(expectedText)) {
    throw new Error(`Validation failed: ${description}`);
  }
}

const repositoryRoot = findRepositoryRoot(process.argv[2]);
const frontendRoot = path.join(repositoryRoot, 'food-ordering-ui');
const sourceRoot = path.join(packageDirectory, 'files');
const timestamp = new Date()
  .toISOString()
  .replace(/[:.]/g, '-')
  .replace('T', '-')
  .replace('Z', '');
const backupRoot = path.join(
  os.tmpdir(),
  `OnlineFoodOrdering-payment-v2-backup-${timestamp}`
);

ensureDirectory(backupRoot);

console.log(`Repository: ${repositoryRoot}`);
console.log(`Backup:     ${backupRoot}`);

const replacementFiles = [
  'food-ordering-ui/src/app/Core/models/order.model.ts',
  'food-ordering-ui/src/app/Core/services/order.service.ts',
  'food-ordering-ui/src/app/app.routes.ts',
  'food-ordering-ui/src/app/features/cart/cart-payment.component.css',
  'food-ordering-ui/src/app/features/order-confirmation/order-confirmation.component.ts',
  'food-ordering-ui/src/app/features/order-confirmation/order-confirmation.component.html',
  'food-ordering-ui/src/app/features/order-confirmation/order-confirmation.component.css'
];

for (const relativePath of replacementFiles) {
  const sourcePath = path.join(sourceRoot, relativePath);
  const targetPath = path.join(repositoryRoot, relativePath);

  if (!fs.existsSync(sourcePath)) {
    throw new Error(`Package file is missing: ${sourcePath}`);
  }

  backupFile(targetPath, repositoryRoot, backupRoot);
  writePackageFile(sourcePath, targetPath);
  console.log(`Updated: ${relativePath}`);
}

const cartTypeScriptPath = path.join(
  frontendRoot,
  'src/app/features/cart/cart.component.ts'
);
const cartTemplatePath = path.join(
  frontendRoot,
  'src/app/features/cart/cart.component.html'
);

backupFile(cartTypeScriptPath, repositoryRoot, backupRoot);
backupFile(cartTemplatePath, repositoryRoot, backupRoot);

const cartTypeScriptOriginal = fs.readFileSync(cartTypeScriptPath, 'utf8');
const cartTypeScriptLineEnding = detectLineEnding(cartTypeScriptOriginal);
let cartTypeScript = normalize(cartTypeScriptOriginal);

if (!cartTypeScript.includes('inject(Router)')) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /import\s*\{\s*RouterLink\s*\}\s*from\s*'@angular\/router';/,
    `import {
  Router,
  RouterLink
} from '@angular/router';`,
    'Import Angular Router'
  );

  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /(^\s*private readonly formBuilder\s*=\s*inject\(FormBuilder\);\s*$)/m,
    `$1
  private readonly router = inject(Router);`,
    'Create the Router dependency'
  );
} else {
  console.log('Already applied: Angular Router dependency');
}

if (!cartTypeScript.includes('PaymentMethod')) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /import\s*\{\s*CheckoutRequest\s*\}\s*from\s*'\.\.\/\.\.\/Core\/models\/order\.model';/,
    `import {
  CheckoutRequest,
  PaymentMethod
} from '../../Core/models/order.model';`,
    'Import the payment model'
  );
} else {
  console.log('Already applied: payment-model import');
}

if (!cartTypeScript.includes("'./cart-payment.component.css'")) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /styleUrl\s*:\s*'\.\/cart\.component\.css'/,
    `styleUrls: [
    './cart.component.css',
    './cart-payment.component.css'
  ]`,
    'Load the payment stylesheet'
  );
} else {
  console.log('Already applied: payment stylesheet');
}

if (!cartTypeScript.includes('signal<PaymentMethod>')) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /(^\s*readonly deliveryInstructions\s*=\s*signal\(''\);\s*$)/m,
    `$1
  readonly paymentMethod =
    signal<PaymentMethod>('CashOnDelivery');`,
    'Create payment-method state'
  );
} else {
  console.log('Already applied: payment-method state');
}

if (!cartTypeScript.includes('selectPaymentMethod(')) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /(^\s*checkout\(\): void \{\s*$)/m,
    `  selectPaymentMethod(paymentMethod: PaymentMethod): void {
    if (this.isCheckingOut()) {
      return;
    }

    this.paymentMethod.set(paymentMethod);
    this.checkoutErrorMessage.set('');
  }

$1`,
    'Add payment selection handling'
  );
} else {
  console.log('Already applied: payment selection handling');
}

if (!cartTypeScript.includes('paymentMethod: this.paymentMethod()')) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /(deliveryInstructions:\s*\n\s*normalizedInstructions\s*\|\|\s*null)(\s*\n\s*\};)/,
    `$1,
      paymentMethod: this.paymentMethod()$2`,
    'Send the payment method during checkout'
  );
} else {
  console.log('Already applied: checkout payment payload');
}

if (!cartTypeScript.includes("'/order-confirmation'")) {
  cartTypeScript = replaceOrThrow(
    cartTypeScript,
    /(\s*this\.deliveryInstructions\.set\(''\);)(\s*\n\s*\},\s*\n\s*error:)/,
    `$1

          void this.router.navigate([
            '/order-confirmation',
            response.order.id
          ]);$2`,
    'Redirect successful checkout to Order Confirmation'
  );
} else {
  console.log('Already applied: checkout redirect');
}

requireText(cartTypeScript, 'inject(Router)', 'Router was not injected.');
requireText(cartTypeScript, 'PaymentMethod', 'PaymentMethod was not imported.');
requireText(
  cartTypeScript,
  "signal<PaymentMethod>('CashOnDelivery')",
  'Payment state was not created.'
);
requireText(
  cartTypeScript,
  'paymentMethod: this.paymentMethod()',
  'Checkout does not send the payment method.'
);
requireText(
  cartTypeScript,
  "'/order-confirmation'",
  'Checkout redirect was not added.'
);

fs.writeFileSync(
  cartTypeScriptPath,
  restoreLineEnding(cartTypeScript, cartTypeScriptLineEnding),
  'utf8'
);
console.log('Updated: food-ordering-ui/src/app/features/cart/cart.component.ts');

const cartTemplateOriginal = fs.readFileSync(cartTemplatePath, 'utf8');
const cartTemplateLineEnding = detectLineEnding(cartTemplateOriginal);
let cartTemplate = normalize(cartTemplateOriginal);

if (!cartTemplate.includes('class="payment-section"')) {
  cartTemplate = replaceOrThrow(
    cartTemplate,
    /(<small>\{\{ deliveryInstructions\(\)\.length \}\}\/500 characters<\/small>\s*<\/section>)/,
    `$1

            <section
              class="payment-section"
              aria-labelledby="payment-heading"
            >
              <div class="payment-section-header">
                <div>
                  <p class="eyebrow">Payment</p>
                  <h2 id="payment-heading">Choose a payment method</h2>
                  <p>Select how you will pay for this order.</p>
                </div>
                <span class="payment-secure-badge">Available</span>
              </div>

              <div
                class="payment-options"
                role="radiogroup"
                aria-labelledby="payment-heading"
              >
                <label
                  class="payment-option"
                  [class.payment-option-selected]="
                    paymentMethod() === 'CashOnDelivery'
                  "
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="CashOnDelivery"
                    [checked]="paymentMethod() === 'CashOnDelivery'"
                    [disabled]="isCheckingOut()"
                    (change)="selectPaymentMethod('CashOnDelivery')"
                  />
                  <span class="payment-option-icon" aria-hidden="true">
                    COD
                  </span>
                  <span class="payment-option-copy">
                    <strong>Cash on Delivery</strong>
                    <small>
                      Pay with cash when your order reaches the delivery address.
                    </small>
                  </span>
                  <span class="payment-option-status">Selected</span>
                </label>
              </div>

              <p class="payment-help">
                Payment status will remain Pending until the cash is collected.
              </p>
            </section>`,
    'Add the payment-method section to Cart'
  );
} else {
  console.log('Already applied: Cart payment section');
}

if (!cartTemplate.includes('class="payment-summary-value"')) {
  cartTemplate = replaceOrThrow(
    cartTemplate,
    /(<div class="summary-row address-summary-row">[\s\S]*?<strong class="missing-address">Select an address<\/strong>[\s\S]*?<\/div>)(\s*<div class="summary-divider"><\/div>)/,
    `$1
              <div class="summary-row">
                <span>Payment</span>
                <strong class="payment-summary-value">
                  Cash on Delivery
                </strong>
              </div>$2`,
    'Show the payment method in the Cart summary'
  );
} else {
  console.log('Already applied: Cart payment summary');
}

requireText(
  cartTemplate,
  'class="payment-section"',
  'The Cart payment section was not added.'
);
requireText(
  cartTemplate,
  'class="payment-summary-value"',
  'The Cart payment summary was not added.'
);

fs.writeFileSync(
  cartTemplatePath,
  restoreLineEnding(cartTemplate, cartTemplateLineEnding),
  'utf8'
);
console.log('Updated: food-ordering-ui/src/app/features/cart/cart.component.html');

console.log('');
console.log('Angular payment and Order Confirmation package v2 applied.');
console.log(`Backup created at: ${backupRoot}`);
console.log('');
console.log('Next commands:');
console.log(`  cd "${frontendRoot}"`);
console.log('  npm run build');
