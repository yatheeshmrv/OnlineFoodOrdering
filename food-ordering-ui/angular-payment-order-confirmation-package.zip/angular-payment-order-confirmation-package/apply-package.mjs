import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packageDirectory = path.dirname(fileURLToPath(import.meta.url));

function findRepositoryRoot(requestedRoot) {
  const candidates = [];

  if (requestedRoot) {
    candidates.push(path.resolve(requestedRoot));
  }

  candidates.push(process.cwd());
  candidates.push(path.resolve(packageDirectory, '..'));

  for (const candidate of candidates) {
    const frontendPackage = path.join(
      candidate,
      'food-ordering-ui',
      'package.json'
    );

    if (fs.existsSync(frontendPackage)) {
      return candidate;
    }
  }

  throw new Error(
    'Unable to locate the OnlineFoodOrdering repository. ' +
      'Run this script from the repository root or pass the repository path.'
  );
}

function toNormalizedText(content) {
  return content.replace(/\r\n/g, '\n');
}

function detectLineEnding(content) {
  return content.includes('\r\n') ? '\r\n' : '\n';
}

function withLineEnding(content, lineEnding) {
  return toNormalizedText(content).replace(/\n/g, lineEnding);
}

function ensureDirectory(directory) {
  fs.mkdirSync(directory, { recursive: true });
}

function backupFile(filePath, repositoryRoot, backupRoot) {
  if (!fs.existsSync(filePath)) {
    return;
  }

  const relativePath = path.relative(repositoryRoot, filePath);
  const backupPath = path.join(backupRoot, relativePath);
  ensureDirectory(path.dirname(backupPath));
  fs.copyFileSync(filePath, backupPath);
}

function writePackageFile(sourcePath, targetPath) {
  const sourceContent = fs.readFileSync(sourcePath, 'utf8');
  const targetContent = fs.existsSync(targetPath)
    ? fs.readFileSync(targetPath, 'utf8')
    : '';
  const lineEnding = targetContent
    ? detectLineEnding(targetContent)
    : os.EOL;

  ensureDirectory(path.dirname(targetPath));
  fs.writeFileSync(
    targetPath,
    withLineEnding(sourceContent, lineEnding),
    'utf8'
  );
}

function replaceRequiredText(
  content,
  oldText,
  newText,
  description
) {
  if (content.includes(newText)) {
    console.log(`Already applied: ${description}`);
    return content;
  }

  if (!content.includes(oldText)) {
    throw new Error(
      `Could not apply "${description}". ` +
        'The current file does not match the expected GitHub version.'
    );
  }

  console.log(`Applied: ${description}`);
  return content.replace(oldText, newText);
}

const repositoryRoot = findRepositoryRoot(process.argv[2]);
const frontendRoot = path.join(repositoryRoot, 'food-ordering-ui');
const sourceRoot = path.join(packageDirectory, 'files');
const timestamp = new Date()
  .toISOString()
  .replace(/[:.]/g, '-')
  .replace('T', '-')
  .replace('Z', '');
const backupRoot = path.join(
  os.tmpdir(),
  `OnlineFoodOrdering-payment-backup-${timestamp}`
);

ensureDirectory(backupRoot);

console.log(`Repository: ${repositoryRoot}`);
console.log(`Backup:     ${backupRoot}`);

const replacementFiles = [
  'food-ordering-ui/src/app/Core/models/order.model.ts',
  'food-ordering-ui/src/app/Core/services/order.service.ts',
  'food-ordering-ui/src/app/app.routes.ts',
  'food-ordering-ui/src/app/features/cart/cart-payment.component.css',
  'food-ordering-ui/src/app/features/order-confirmation/order-confirmation.component.ts',
  'food-ordering-ui/src/app/features/order-confirmation/order-confirmation.component.html',
  'food-ordering-ui/src/app/features/order-confirmation/order-confirmation.component.css'
];

for (const relativePath of replacementFiles) {
  const sourcePath = path.join(sourceRoot, relativePath);
  const targetPath = path.join(repositoryRoot, relativePath);

  if (!fs.existsSync(sourcePath)) {
    throw new Error(`Package file is missing: ${sourcePath}`);
  }

  backupFile(targetPath, repositoryRoot, backupRoot);
  writePackageFile(sourcePath, targetPath);
  console.log(`Updated: ${relativePath}`);
}

const cartTypeScriptPath = path.join(
  frontendRoot,
  'src/app/features/cart/cart.component.ts'
);
const cartTemplatePath = path.join(
  frontendRoot,
  'src/app/features/cart/cart.component.html'
);

backupFile(cartTypeScriptPath, repositoryRoot, backupRoot);
backupFile(cartTemplatePath, repositoryRoot, backupRoot);

const cartTypeScriptOriginal = fs.readFileSync(
  cartTypeScriptPath,
  'utf8'
);
const cartTypeScriptLineEnding = detectLineEnding(
  cartTypeScriptOriginal
);
let cartTypeScript = toNormalizedText(cartTypeScriptOriginal);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  "import { RouterLink } from '@angular/router';",
  `import {
  Router,
  RouterLink
} from '@angular/router';`,
  'Inject Angular Router'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  "import { CheckoutRequest } from '../../Core/models/order.model';",
  `import {
  CheckoutRequest,
  PaymentMethod
} from '../../Core/models/order.model';`,
  'Import payment model'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  "  styleUrl: './cart.component.css'",
  `  styleUrls: [
    './cart.component.css',
    './cart-payment.component.css'
  ]`,
  'Load the additional Cart payment stylesheet'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  `  private readonly formBuilder = inject(FormBuilder);
  readonly cart = signal<CartModel | null>(null);`,
  `  private readonly formBuilder = inject(FormBuilder);
  private readonly router = inject(Router);

  readonly cart = signal<CartModel | null>(null);`,
  'Create the Router dependency'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  `  readonly deliveryInstructions = signal('');
  readonly addressForm = this.formBuilder.nonNullable.group({`,
  `  readonly deliveryInstructions = signal('');
  readonly paymentMethod =
    signal<PaymentMethod>('CashOnDelivery');

  readonly addressForm = this.formBuilder.nonNullable.group({`,
  'Create payment-method state'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  `  updateDeliveryInstructions(event: Event): void {
    const textarea = event.target as HTMLTextAreaElement;
    this.deliveryInstructions.set(textarea.value);
  }

  checkout(): void {`,
  `  updateDeliveryInstructions(event: Event): void {
    const textarea = event.target as HTMLTextAreaElement;
    this.deliveryInstructions.set(textarea.value);
  }

  selectPaymentMethod(paymentMethod: PaymentMethod): void {
    if (this.isCheckingOut()) {
      return;
    }

    this.paymentMethod.set(paymentMethod);
    this.checkoutErrorMessage.set('');
  }

  checkout(): void {`,
  'Add payment selection handling'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  `      deliveryInstructions:
        normalizedInstructions || null`,
  `      deliveryInstructions:
        normalizedInstructions || null,
      paymentMethod: this.paymentMethod()`,
  'Send the payment method during checkout'
);

cartTypeScript = replaceRequiredText(
  cartTypeScript,
  `          this.deliveryInstructions.set('');
        },`,
  `          this.deliveryInstructions.set('');

          void this.router.navigate([
            '/order-confirmation',
            response.order.id
          ]);
        },`,
  'Redirect successful checkout to Order Confirmation'
);

fs.writeFileSync(
  cartTypeScriptPath,
  withLineEnding(cartTypeScript, cartTypeScriptLineEnding),
  'utf8'
);

const cartTemplateOriginal = fs.readFileSync(
  cartTemplatePath,
  'utf8'
);
const cartTemplateLineEnding = detectLineEnding(
  cartTemplateOriginal
);
let cartTemplate = toNormalizedText(cartTemplateOriginal);

cartTemplate = replaceRequiredText(
  cartTemplate,
  `              <small>{{ deliveryInstructions().length }}/500 characters</small>
            </section>`,
  `              <small>{{ deliveryInstructions().length }}/500 characters</small>
            </section>

            <section
              class="payment-section"
              aria-labelledby="payment-heading"
            >
              <div class="payment-section-header">
                <div>
                  <p class="eyebrow">Payment</p>
                  <h2 id="payment-heading">Choose a payment method</h2>
                  <p>
                    Select how you will pay for this order.
                  </p>
                </div>
                <span class="payment-secure-badge">Available</span>
              </div>

              <div
                class="payment-options"
                role="radiogroup"
                aria-labelledby="payment-heading"
              >
                <label
                  class="payment-option"
                  [class.payment-option-selected]="
                    paymentMethod() === 'CashOnDelivery'
                  "
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="CashOnDelivery"
                    [checked]="paymentMethod() === 'CashOnDelivery'"
                    [disabled]="isCheckingOut()"
                    (change)="selectPaymentMethod('CashOnDelivery')"
                  />
                  <span class="payment-option-icon" aria-hidden="true">
                    COD
                  </span>
                  <span class="payment-option-copy">
                    <strong>Cash on Delivery</strong>
                    <small>
                      Pay with cash when your order reaches the delivery address.
                    </small>
                  </span>
                  <span class="payment-option-status">Selected</span>
                </label>
              </div>

              <p class="payment-help">
                Payment status will remain Pending until the cash is collected.
              </p>
            </section>`,
  'Add the payment-method section to Cart'
);

cartTemplate = replaceRequiredText(
  cartTemplate,
  `                } @else {
                  <strong class="missing-address">Select an address</strong>
                }
              </div>
              <div class="summary-divider"></div>`,
  `                } @else {
                  <strong class="missing-address">Select an address</strong>
                }
              </div>
              <div class="summary-row">
                <span>Payment</span>
                <strong class="payment-summary-value">
                  Cash on Delivery
                </strong>
              </div>
              <div class="summary-divider"></div>`,
  'Show the payment method in the Cart summary'
);

fs.writeFileSync(
  cartTemplatePath,
  withLineEnding(cartTemplate, cartTemplateLineEnding),
  'utf8'
);

console.log('');
console.log('Angular payment and Order Confirmation package applied.');
console.log(`Backup created at: ${backupRoot}`);
console.log('');
console.log('Next commands:');
console.log(`  cd "${frontendRoot}"`);
console.log('  npm run build');
